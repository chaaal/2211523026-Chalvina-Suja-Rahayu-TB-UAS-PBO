public class Penutup {
   public String thanks;
   public  String bye;

    //constructor
    public Penutup (String thanks, String bye)
    {
            this.thanks = thanks;
            this.bye = bye;
    }
    // constructor
    public Penutup(){

    }
}  